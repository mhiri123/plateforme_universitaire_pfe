import 'package:get/get.dart';

class AboutUsController extends GetxController {
  // You can add any dynamic data here if needed, such as text from an API
  var companyName = "Your Company Name".obs;
  var mission = "Our mission is to simplify the process...".obs;
  var vision = "We envision a world where education is more accessible...".obs;
  var email = "support@yourcompany.com".obs;
  var phone = "+123 456 7890".obs;
}
