import 'package:flutter/material.dart';
import '../../home/views/home_screen.dart';
import '../../login/views/login_view.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';// Import du LoginScreen
// Import du HomeScreen

class AboutUsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            Text(
              "REO",
              style: TextStyle(color: Colors.red, fontSize: 22, fontWeight: FontWeight.bold),
            ),
            Spacer(),
            TextButton(
              onPressed: () {
                // Naviguer vers HomeScreen
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => HomeScreen()),
                );
              },
              child: Text("HOME", style: TextStyle(color: Colors.black)),
            ),
            TextButton(
              onPressed: () {},
              child: Text("NEWS", style: TextStyle(color: Colors.black)),
            ),
            TextButton(
              onPressed: () {},
              child: Text("ABOUT US", style: TextStyle(color: Colors.black)),
            ),
            TextButton(
              onPressed: () {},
              child: Text("SERVICES", style: TextStyle(color: Colors.black)),
            ),
            TextButton(
              onPressed: () {},
              child: Text("CONTACT", style: TextStyle(color: Colors.black)),
            ),
            SizedBox(width: 20),
            ElevatedButton(
              onPressed: () {},
              child: Text("ENQUIRE TODAY"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            ),
            SizedBox(width: 10),
            ElevatedButton(
              onPressed: () {
                // Naviguer vers LoginScreen
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                );
              },
              child: Text("LOGIN"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Titre de bienvenue
              Text(
                "Welcome to Our Platform",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.red),
              ),
              SizedBox(height: 20),

              // Description de la plateforme
              Text(
                "At [Your Company Name], we are dedicated to providing innovative solutions that empower students, teachers, and administrators to collaborate efficiently. Our platform bridges the gap between academic requirements and real-time communication, enhancing the educational experience for all users.",
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
              SizedBox(height: 20),

              // Mission de la plateforme
              Text(
                "Our Mission",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red),
              ),
              SizedBox(height: 10),
              Text(
                "Our mission is to simplify the process of academic transfers, reorientations, and communication. By offering an easy-to-use platform, we aim to make the transition between faculties and disciplines seamless and provide a space where students, teachers, and administrators can collaborate and communicate effectively.",
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
              SizedBox(height: 20),

              // Vision de la plateforme
              Text(
                "Our Vision",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red),
              ),
              SizedBox(height: 10),
              Text(
                "We envision a world where education is more accessible, efficient, and collaborative. We aim to create an ecosystem where educational institutions can thrive, offering students the tools they need to succeed and teachers the resources to guide them.",
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
              SizedBox(height: 20),

              // Section Contactez-nous
              Text(
                "Contact Us",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.red),
              ),
              SizedBox(height: 10),
              Text(
                "For inquiries or support, please reach out to us at:",
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
              SizedBox(height: 5),
              Text(
                "Email: support@yourcompany.com",
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
              SizedBox(height: 5),
              Text(
                "Phone: +123 456 7890",
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
              SizedBox(height: 30),

              // Section avec des icônes (facultatif)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: Icon(Icons.facebook, color: Colors.blue, size: 30),
                    onPressed: () {
                      // Action Facebook
                    },
                  ),
                  IconButton(
                    icon: Icon(FontAwesomeIcons.twitter, color: Colors.blue, size: 30),
                    onPressed: () {
                    },
                  ),
                  IconButton(
                    icon: Icon( FontAwesomeIcons.linkedin, color: Colors.blue, size: 30),
                    onPressed: () {
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
